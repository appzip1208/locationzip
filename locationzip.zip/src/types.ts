export type Region = '전체' | '서울' | '구리' | '남양주';

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number; // 1 to 5
  content: string;
  photoUrl?: string;
  createdAt: string;
  likes: number;
  tags?: string[];
}

export interface Spot {
  id: string;
  themeId: string;
  themeName: string;
  themeIcon: string;
  themeBadgeColor: string; // e.g. bg-purple-100 text-purple-700
  title: string;
  description: string;
  region: '서울' | '구리' | '남양주';
  district: string; // e.g. '인창동', '갈매동', '별내동', '다산동', '중랑구'
  address: string;
  lat: number;
  lng: number;
  rating: number;
  reviewCount: number;
  likes: number;
  imageUrl: string;
  tags: string[];
  author: string;
  createdAt: string;
  reviews: Review[];
  isBookmarked?: boolean;
}

export interface ThemeMap {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  badgeBg: string;
  spotCount: number;
  contributorCount: number;
  isPopular?: boolean;
  category: string;
}

export interface CommunityFeedItem {
  id: string;
  type: 'spot_added' | 'review_added' | 'theme_created';
  userName: string;
  userAvatar: string;
  title: string;
  region: string;
  timeAgo: string;
  likes: number;
}
