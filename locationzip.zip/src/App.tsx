import React, { useState, useMemo } from 'react';
import { Spot, ThemeMap, Region, Review, CommunityFeedItem } from './types';
import { INITIAL_SPOTS, INITIAL_THEMES, INITIAL_FEED } from './data/mockData';
import { Header } from './components/Header';
import { ThemeFilter } from './components/ThemeFilter';
import { MapView } from './components/MapView';
import { PopularThemes } from './components/PopularThemes';
import { RecentSpots } from './components/RecentSpots';
import { RegisterBanner } from './components/RegisterBanner';
import { SpotDetailModal } from './components/SpotDetailModal';
import { AddSpotModal } from './components/AddSpotModal';
import { CreateThemeModal } from './components/CreateThemeModal';
import { CommunityMappingInfo } from './components/CommunityMappingInfo';
import { MyPage } from './components/MyPage';
import { BottomNav, TabType } from './components/BottomNav';
import { Sparkles, Map, Search, Flame, ArrowRight } from 'lucide-react';

export default function App() {
  const [spots, setSpots] = useState<Spot[]>(INITIAL_SPOTS);
  const [themes, setThemes] = useState<ThemeMap[]>(INITIAL_THEMES);
  const [feedItems, setFeedItems] = useState<CommunityFeedItem[]>(INITIAL_FEED);

  // Filters
  const [selectedRegion, setSelectedRegion] = useState<Region>('전체');
  const [selectedThemeId, setSelectedThemeId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentTab, setCurrentTab] = useState<TabType>('home');

  // Modals & Active Selections
  const [selectedSpot, setSelectedSpot] = useState<Spot | null>(null);
  const [detailModalSpot, setDetailModalSpot] = useState<Spot | null>(null);
  const [isAddSpotOpen, setIsAddSpotOpen] = useState<boolean>(false);
  const [isCreateThemeOpen, setIsCreateThemeOpen] = useState<boolean>(false);

  // Interactive Pin Picking Mode
  const [isPickLocationMode, setIsPickLocationMode] = useState<boolean>(false);
  const [pickedLocation, setPickedLocation] = useState<{ lat: number; lng: number; address?: string } | null>(null);

  // Filtered Spots Logic
  const filteredSpots = useMemo(() => {
    return spots.filter((spot) => {
      // Region Filter
      if (selectedRegion !== '전체' && spot.region !== selectedRegion) {
        return false;
      }
      // Theme Filter
      if (selectedThemeId !== 'all' && spot.themeId !== selectedThemeId) {
        return false;
      }
      // Search Query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = spot.title.toLowerCase().includes(query);
        const matchesDesc = spot.description.toLowerCase().includes(query);
        const matchesAddr = spot.address.toLowerCase().includes(query);
        const matchesTheme = spot.themeName.toLowerCase().includes(query);
        const matchesTags = spot.tags?.some((t) => t.toLowerCase().includes(query));
        return matchesTitle || matchesDesc || matchesAddr || matchesTheme || matchesTags;
      }
      return true;
    });
  }, [spots, selectedRegion, selectedThemeId, searchQuery]);

  // Bookmarked spots
  const bookmarkedSpots = useMemo(() => spots.filter((s) => s.isBookmarked), [spots]);
  // My created spots
  const mySpots = useMemo(() => spots.filter((s) => s.author === '구리냥이덕후' || s.author === '동네이웃'), [spots]);

  // Handlers
  const handleToggleBookmark = (spotId: string) => {
    setSpots((prev) =>
      prev.map((s) => (s.id === spotId ? { ...s, isBookmarked: !s.isBookmarked } : s))
    );
    if (selectedSpot && selectedSpot.id === spotId) {
      setSelectedSpot((prev) => (prev ? { ...prev, isBookmarked: !prev.isBookmarked } : null));
    }
    if (detailModalSpot && detailModalSpot.id === spotId) {
      setDetailModalSpot((prev) => (prev ? { ...prev, isBookmarked: !prev.isBookmarked } : null));
    }
  };

  const handleLikeSpot = (spotId: string) => {
    setSpots((prev) =>
      prev.map((s) => (s.id === spotId ? { ...s, likes: s.likes + 1 } : s))
    );
    if (selectedSpot && selectedSpot.id === spotId) {
      setSelectedSpot((prev) => (prev ? { ...prev, likes: prev.likes + 1 } : null));
    }
    if (detailModalSpot && detailModalSpot.id === spotId) {
      setDetailModalSpot((prev) => (prev ? { ...prev, likes: prev.likes + 1 } : null));
    }
  };

  const handleAddReview = (spotId: string, reviewData: Omit<Review, 'id' | 'createdAt' | 'likes'>) => {
    const newRev: Review = {
      ...reviewData,
      id: `rev_${Date.now()}`,
      createdAt: '방금 전',
      likes: 0,
    };

    setSpots((prev) =>
      prev.map((s) => {
        if (s.id === spotId) {
          const updatedReviews = [newRev, ...s.reviews];
          const totalRating = updatedReviews.reduce((acc, r) => acc + r.rating, 0);
          const avgRating = totalRating / updatedReviews.length;
          return {
            ...s,
            reviews: updatedReviews,
            reviewCount: updatedReviews.length,
            rating: avgRating,
          };
        }
        return s;
      })
    );

    // Update open modal spot
    if (detailModalSpot && detailModalSpot.id === spotId) {
      const updatedReviews = [newRev, ...detailModalSpot.reviews];
      const totalRating = updatedReviews.reduce((acc, r) => acc + r.rating, 0);
      setDetailModalSpot({
        ...detailModalSpot,
        reviews: updatedReviews,
        reviewCount: updatedReviews.length,
        rating: totalRating / updatedReviews.length,
      });
    }

    // Add activity feed entry
    setFeedItems((prev) => [
      {
        id: `feed_${Date.now()}`,
        type: 'review_added',
        userName: reviewData.userName,
        userAvatar: '💬',
        title: `${detailModalSpot?.title || '스팟'}에 새로운 후기를 남겼습니다.`,
        region: `${detailModalSpot?.region || '우리동네'}`,
        timeAgo: '방금 전',
        likes: 1,
      },
      ...prev,
    ]);
  };

  const handleAddSpot = (
    newSpotData: Omit<Spot, 'id' | 'rating' | 'reviewCount' | 'likes' | 'createdAt' | 'reviews'>
  ) => {
    const newSpot: Spot = {
      ...newSpotData,
      id: `spot_${Date.now()}`,
      rating: 5.0,
      reviewCount: 1,
      likes: 1,
      createdAt: '방금 전',
      reviews: [
        {
          id: `rev_init_${Date.now()}`,
          userId: 'u_author',
          userName: newSpotData.author,
          rating: 5,
          content: '주민 제보 스팟입니다! 많은 이용 부탁드립니다.',
          createdAt: '방금 전',
          likes: 0,
        },
      ],
    };

    setSpots((prev) => [newSpot, ...prev]);

    // Update theme spot count
    setThemes((prev) =>
      prev.map((t) => (t.id === newSpotData.themeId ? { ...t, spotCount: t.spotCount + 1 } : t))
    );

    // Add feed item
    setFeedItems((prev) => [
      {
        id: `feed_${Date.now()}`,
        type: 'spot_added',
        userName: newSpotData.author,
        userAvatar: newSpotData.themeIcon,
        title: `${newSpotData.title} 스팟이 새롭게 등록되었습니다!`,
        region: `${newSpotData.region} ${newSpotData.district}`,
        timeAgo: '방금 전',
        likes: 3,
      },
      ...prev,
    ]);

    setIsPickLocationMode(false);
    setPickedLocation(null);
  };

  const handleCreateTheme = (newTheme: ThemeMap) => {
    setThemes((prev) => [newTheme, ...prev]);
    setSelectedThemeId(newTheme.id);

    setFeedItems((prev) => [
      {
        id: `feed_${Date.now()}`,
        type: 'theme_created',
        userName: '동네이웃',
        userAvatar: newTheme.icon,
        title: `새 테마 [${newTheme.name}] 지도 개설!`,
        region: '서울·구리·남양주 전체',
        timeAgo: '방금 전',
        likes: 12,
      },
      ...prev,
    ]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50/50 via-white to-purple-50/30 text-gray-900 pb-24 font-sans antialiased max-w-md mx-auto shadow-2xl border-x border-purple-100/60">
      {/* Top Header */}
      <Header
        selectedRegion={selectedRegion}
        onSelectRegion={setSelectedRegion}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Main Tab Switcher */}
      {currentTab === 'home' && (
        <main className="space-y-1">
          {/* Theme Filter Chips Bar */}
          <ThemeFilter
            themes={themes}
            selectedThemeId={selectedThemeId}
            onSelectTheme={setSelectedThemeId}
            onCreateNewTheme={() => setIsCreateThemeOpen(true)}
          />

          {/* Map View */}
          <section className="px-4 py-1">
            <MapView
              spots={filteredSpots}
              selectedSpot={selectedSpot}
              onSelectSpot={setSelectedSpot}
              onOpenDetail={(s) => setDetailModalSpot(s)}
              selectedRegion={selectedRegion}
              isPickMode={isPickLocationMode}
              pickedLocation={pickedLocation}
              onPickLocation={(loc) => {
                setPickedLocation(loc);
                setIsPickLocationMode(false);
                setIsAddSpotOpen(true);
              }}
              onToggleBookmark={handleToggleBookmark}
            />
          </section>

          {/* Popular Themes Carousel matching Image 1 */}
          <PopularThemes
            themes={themes}
            onSelectTheme={(tId) => {
              setSelectedThemeId(tId);
              window.scrollTo({ top: 120, behavior: 'smooth' });
            }}
            onViewAllThemes={() => setCurrentTab('themes')}
          />

          {/* Register Banner matching Image 1 */}
          <RegisterBanner onOpenAddSpot={() => setIsAddSpotOpen(true)} />

          {/* Recently Added Spots List matching Image 1 */}
          <RecentSpots
            spots={filteredSpots}
            onOpenDetail={(s) => setDetailModalSpot(s)}
            onToggleBookmark={handleToggleBookmark}
            onViewMore={() => setCurrentTab('themes')}
          />
        </main>
      )}

      {/* Themes Directory Tab */}
      {currentTab === 'themes' && (
        <div className="px-4 py-4 space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-extrabold text-gray-900">우리동네 테마 지도 모음</h2>
              <p className="text-xs text-gray-500">주민들이 관심 주제로 소통하며 만드는 지도를 탐색해보세요</p>
            </div>
            <button
              onClick={() => setIsCreateThemeOpen(true)}
              className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold px-3 py-1.5 rounded-2xl shadow-xs transition cursor-pointer"
            >
              + 테마 만들기
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {themes.map((theme) => {
              const themeSpots = spots.filter((s) => s.themeId === theme.id);
              return (
                <div
                  key={theme.id}
                  onClick={() => {
                    setSelectedThemeId(theme.id);
                    setCurrentTab('home');
                  }}
                  className="p-4 bg-white rounded-3xl border border-purple-100 shadow-xs hover:shadow-md transition cursor-pointer group space-y-2"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-purple-50 group-hover:bg-purple-100 flex items-center justify-center text-3xl transition shadow-inner">
                        {theme.icon}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h3 className="text-sm font-bold text-gray-900 group-hover:text-purple-700 transition">
                            {theme.name}
                          </h3>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${theme.badgeBg}`}>
                            {theme.category}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 line-clamp-1 mt-0.5">{theme.description}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-400 font-medium pt-1 border-t border-gray-50">
                    <span>등록된 스팟 {themeSpots.length}개</span>
                    <span className="text-purple-600 font-bold group-hover:translate-x-1 transition flex items-center gap-0.5">
                      지도에서 보기 <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Community & Mapping Guide Tab matching Image 2 */}
      {currentTab === 'community' && (
        <CommunityMappingInfo
          feedItems={feedItems}
          onOpenAddSpot={() => setIsAddSpotOpen(true)}
          onCreateTheme={() => setIsCreateThemeOpen(true)}
        />
      )}

      {/* My Page Tab */}
      {currentTab === 'mypage' && (
        <MyPage
          bookmarkedSpots={bookmarkedSpots}
          mySpots={mySpots}
          onOpenSpotDetail={(s) => setDetailModalSpot(s)}
          onToggleBookmark={handleToggleBookmark}
        />
      )}

      {/* Modals */}
      <SpotDetailModal
        spot={detailModalSpot}
        onClose={() => setDetailModalSpot(null)}
        onAddReview={handleAddReview}
        onToggleBookmark={handleToggleBookmark}
        onLikeSpot={handleLikeSpot}
      />

      <AddSpotModal
        isOpen={isAddSpotOpen}
        onClose={() => setIsAddSpotOpen(false)}
        themes={themes}
        onAddSpot={handleAddSpot}
        onStartPickLocation={() => {
          setIsPickLocationMode(true);
          setCurrentTab('home');
        }}
        pickedLocation={pickedLocation}
      />

      <CreateThemeModal
        isOpen={isCreateThemeOpen}
        onClose={() => setIsCreateThemeOpen(false)}
        onCreateTheme={handleCreateTheme}
      />

      {/* Bottom Fixed Navigation Bar matching Image 1 */}
      <BottomNav
        currentTab={currentTab}
        onChangeTab={setCurrentTab}
        onOpenAddSpot={() => setIsAddSpotOpen(true)}
        onOpenCreateTheme={() => setIsCreateThemeOpen(true)}
      />
    </div>
  );
}
