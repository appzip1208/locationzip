import React from 'react';
import { Plus, MapPin } from 'lucide-react';

interface RegisterBannerProps {
  onOpenAddSpot: () => void;
}

export const RegisterBanner: React.FC<RegisterBannerProps> = ({ onOpenAddSpot }) => {
  return (
    <div className="px-4 py-2 my-1">
      <div
        onClick={onOpenAddSpot}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-100 via-purple-50 to-pink-100 border border-purple-200/80 p-3.5 shadow-sm hover:shadow-md transition cursor-pointer group"
      >
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-600 group-hover:bg-purple-700 text-white flex items-center justify-center shadow-md transition transform group-hover:scale-105">
              <Plus className="w-6 h-6 stroke-[3]" />
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="text-xs font-bold text-purple-800">스팟 등록하기</span>
                <MapPin className="w-3.5 h-3.5 text-pink-500" />
              </div>
              <p className="text-[11px] font-semibold text-purple-600/90">
                우리 동네의 특별한 비밀 스팟을 공유해 보세요!
              </p>
            </div>
          </div>

          {/* Graphic matching the carousel / park motif on right */}
          <div className="text-3xl opacity-80 group-hover:scale-110 transition duration-300">
            🎠
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-pink-300/30 rounded-full blur-xl pointer-events-none"></div>
      </div>
    </div>
  );
};
