import React from 'react';
import { ThemeMap } from '../types';
import { Plus } from 'lucide-react';

interface ThemeFilterProps {
  themes: ThemeMap[];
  selectedThemeId: string;
  onSelectTheme: (themeId: string) => void;
  onCreateNewTheme: () => void;
}

export const ThemeFilter: React.FC<ThemeFilterProps> = ({
  themes,
  selectedThemeId,
  onSelectTheme,
  onCreateNewTheme,
}) => {
  return (
    <div className="py-2.5 px-4 overflow-x-auto no-scrollbar flex items-center gap-2">
      {/* "전체" Pill */}
      <button
        onClick={() => onSelectTheme('all')}
        className={`px-3.5 py-1.5 rounded-2xl text-xs font-bold shrink-0 transition-all cursor-pointer shadow-xs ${
          selectedThemeId === 'all'
            ? 'bg-purple-600 text-white shadow-purple-200 scale-105 ring-2 ring-purple-300'
            : 'bg-white text-gray-700 hover:bg-purple-50 border border-gray-100'
        }`}
      >
        전체
      </button>

      {/* Theme Pills matching design icons */}
      {themes.map((theme) => {
        const isSelected = selectedThemeId === theme.id;
        return (
          <button
            key={theme.id}
            onClick={() => onSelectTheme(theme.id)}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl text-xs font-bold shrink-0 transition-all cursor-pointer shadow-xs ${
              isSelected
                ? 'bg-purple-600 text-white shadow-purple-200 scale-105 ring-2 ring-purple-300'
                : 'bg-white text-gray-700 hover:bg-purple-50 border border-purple-100/70'
            }`}
          >
            <span className="text-sm">{theme.icon}</span>
            <span>{theme.name}</span>
          </button>
        );
      })}

      {/* "+ 새 테마 만들기" Action Pill */}
      <button
        onClick={onCreateNewTheme}
        className="flex items-center gap-1 px-3.5 py-1.5 bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white rounded-2xl text-xs font-bold shrink-0 shadow-xs transition transform active:scale-95 cursor-pointer"
      >
        <Plus className="w-3.5 h-3.5" />
        <span>새 테마 지도</span>
      </button>
    </div>
  );
};
