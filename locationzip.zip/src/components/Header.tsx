import React from 'react';
import { Bell, Search } from 'lucide-react';
import { Region } from '../types';
import logoImage from '../assets/images/logo.png';

interface HeaderProps {
  selectedRegion: Region;
  onSelectRegion: (region: Region) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  unreadCount?: number;
}

const REGIONS: Region[] = ['전체', '서울', '구리', '남양주'];

export const Header: React.FC<HeaderProps> = ({
  selectedRegion,
  onSelectRegion,
  searchQuery,
  onSearchChange,
  unreadCount = 2,
}) => {
  return (
    <header className="pt-2 pb-3 px-4 bg-gradient-to-b from-purple-100/60 via-purple-50/40 to-white border-b border-purple-100">
      {/* Top Bar with Carousel Title & Actions */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <img
            src={logoImage}
            alt="우리동네 테마파크"
            className="h-10 sm:h-12 w-auto object-contain mix-blend-multiply rounded-md scale-[1.05] origin-left"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Region Pills & Bell Notification */}
        <div className="flex items-center gap-2">
          {/* Regional Selector Pill Group */}
          <div className="flex bg-white/80 backdrop-blur-xs p-1 rounded-full border border-purple-100 shadow-xs">
            {REGIONS.map((region) => {
              const isActive = selectedRegion === region;
              return (
                <button
                  key={region}
                  onClick={() => onSelectRegion(region)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-full transition-all cursor-pointer ${
                    isActive
                      ? 'bg-purple-600 text-white shadow-xs scale-105'
                      : 'text-gray-600 hover:text-purple-600 hover:bg-purple-50'
                  }`}
                >
                  {region}
                </button>
              );
            })}
          </div>

          {/* Notification Bell */}
          <button
            className="relative p-2 text-gray-600 hover:text-purple-700 hover:bg-purple-100/50 rounded-full transition cursor-pointer"
            title="알림"
          >
            <Bell className="w-5 h-5 text-purple-700" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-pink-500 rounded-full ring-2 ring-white"></span>
            )}
          </button>
        </div>
      </div>

      {/* Search Input Bar matching design image ("어떤 지도를 보고 계신가요?") */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="어떤 지도를 보고 계신가요? (예: 고양이, 붕어빵, 약국, 카페)"
          className="w-full bg-white/90 focus:bg-white text-xs font-medium text-gray-800 placeholder-gray-400 pl-10 pr-4 py-2.5 rounded-2xl border border-purple-100 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-400 transition"
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400 hover:text-gray-600 cursor-pointer"
          >
            ✕
          </button>
        )}
      </div>
    </header>
  );
};
