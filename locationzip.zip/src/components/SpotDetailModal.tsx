import React, { useState } from 'react';
import { Spot, Review } from '../types';
import { X, Star, Heart, MapPin, Share2, Bookmark, Send, Image as ImageIcon, CheckCircle, ThumbsUp } from 'lucide-react';

interface SpotDetailModalProps {
  spot: Spot | null;
  onClose: () => void;
  onAddReview: (spotId: string, review: Omit<Review, 'id' | 'createdAt' | 'likes'>) => void;
  onToggleBookmark: (spotId: string) => void;
  onLikeSpot: (spotId: string) => void;
}

export const SpotDetailModal: React.FC<SpotDetailModalProps> = ({
  spot,
  onClose,
  onAddReview,
  onToggleBookmark,
  onLikeSpot,
}) => {
  if (!spot) return null;

  const [rating, setRating] = useState<number>(5);
  const [content, setContent] = useState<string>('');
  const [tagInput, setTagInput] = useState<string>('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [reviewPhotoUrl, setReviewPhotoUrl] = useState<string>('');
  const [userName, setUserName] = useState<string>('');
  const [copiedNotification, setCopiedNotification] = useState<boolean>(false);

  const PRESET_REVIEW_TAGS = ['친절함', '깨끗함', '귀여움', '24시간', '주차가능', '분위기좋음', '재방문의사100%'];

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    onAddReview(spot.id, {
      userId: 'user_me',
      userName: userName.trim() || '동네주민',
      rating,
      content,
      photoUrl: reviewPhotoUrl || undefined,
      tags: selectedTags,
    });

    setContent('');
    setReviewPhotoUrl('');
    setSelectedTags([]);
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl max-h-[90vh] overflow-y-auto no-scrollbar shadow-2xl border border-purple-100 flex flex-col">
        {/* Header Image & Actions */}
        <div className="relative w-full h-52 sm:h-60 bg-gray-100 shrink-0">
          <img
            src={spot.imageUrl}
            alt={spot.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-3 right-3 w-9 h-9 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center backdrop-blur-xs transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Top category badge */}
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1 bg-white/90 backdrop-blur-xs rounded-full shadow-sm text-xs font-bold text-purple-900">
            <span>{spot.themeIcon}</span>
            <span>{spot.themeName}</span>
          </div>

          {/* Bottom Title overlay */}
          <div className="absolute bottom-3 left-4 right-4 text-white">
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-purple-600/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-md">
                {spot.region} {spot.district}
              </span>
              <span className="text-xs text-gray-200">작성자: {spot.author}</span>
            </div>
            <h2 className="text-xl font-extrabold text-white leading-tight drop-shadow-sm">
              {spot.title}
            </h2>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-4 flex-1">
          {/* Quick Action Bar & Stats */}
          <div className="flex items-center justify-between bg-purple-50/60 p-3 rounded-2xl border border-purple-100">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1 text-amber-500 font-extrabold text-lg">
                <Star className="w-5 h-5 fill-amber-400" />
                <span>{spot.rating.toFixed(1)}</span>
                <span className="text-xs text-gray-500 font-normal">
                  ({spot.reviewCount}개의 후기)
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onLikeSpot(spot.id)}
                className="flex items-center gap-1 px-3 py-1.5 bg-white hover:bg-pink-50 text-pink-600 rounded-xl border border-pink-200 text-xs font-bold shadow-2xs transition cursor-pointer"
              >
                <Heart className="w-4 h-4 fill-pink-500 text-pink-500" />
                <span>{spot.likes}</span>
              </button>

              <button
                onClick={() => onToggleBookmark(spot.id)}
                className={`p-2 rounded-xl border transition cursor-pointer ${
                  spot.isBookmarked
                    ? 'bg-purple-600 text-white border-purple-700'
                    : 'bg-white text-gray-600 border-gray-200 hover:bg-purple-50'
                }`}
                title="스팟 저장"
              >
                <Bookmark className={`w-4 h-4 ${spot.isBookmarked ? 'fill-white' : ''}`} />
              </button>

              <button
                onClick={handleShare}
                className="p-2 bg-white hover:bg-gray-100 text-gray-600 rounded-xl border border-gray-200 transition cursor-pointer relative"
                title="공유하기"
              >
                <Share2 className="w-4 h-4" />
                {copiedNotification && (
                  <span className="absolute -top-8 right-0 bg-gray-900 text-white text-[10px] px-2 py-1 rounded shadow-md whitespace-nowrap">
                    링크가 복사되었습니다!
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Address & Location */}
          <div className="flex items-start gap-2 text-xs text-gray-700 bg-gray-50 p-3 rounded-2xl border border-gray-100">
            <MapPin className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-gray-900">{spot.address}</p>
              <p className="text-gray-500 text-[11px] mt-0.5">
                위도: {spot.lat.toFixed(4)}, 경도: {spot.lng.toFixed(4)}
              </p>
            </div>
          </div>

          {/* Spot Description */}
          <div className="space-y-1">
            <h3 className="text-xs font-bold text-gray-900">💡 스팟 정보</h3>
            <p className="text-xs text-gray-700 leading-relaxed whitespace-pre-line bg-purple-50/30 p-3 rounded-2xl border border-purple-100/50">
              {spot.description}
            </p>
          </div>

          {/* Tags */}
          {spot.tags && spot.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {spot.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 bg-purple-100/70 text-purple-800 rounded-full text-[11px] font-semibold"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}

          <hr className="border-gray-100" />

          {/* Reviews List Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-gray-900 flex items-center gap-1.5">
                <span>💬 주민 방문 후기</span>
                <span className="text-purple-600 font-extrabold">({spot.reviews.length})</span>
              </h3>
            </div>

            {spot.reviews.length === 0 ? (
              <div className="text-center py-6 bg-gray-50 rounded-2xl border border-dashed border-gray-200 text-gray-400 text-xs">
                첫 방문 후기를 남겨주세요! 🐾
              </div>
            ) : (
              <div className="space-y-2.5 max-h-60 overflow-y-auto no-scrollbar pr-1">
                {spot.reviews.map((rev) => (
                  <div
                    key={rev.id}
                    className="p-3 bg-white rounded-2xl border border-gray-100 shadow-2xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-700 font-bold text-xs flex items-center justify-center">
                          {rev.userName.slice(0, 1)}
                        </div>
                        <span className="text-xs font-bold text-gray-800">{rev.userName}</span>
                        <span className="text-[10px] text-gray-400">{rev.createdAt}</span>
                      </div>

                      <div className="flex items-center text-amber-400 text-xs font-bold">
                        ★ {rev.rating.toFixed(1)}
                      </div>
                    </div>

                    <p className="text-xs text-gray-700 leading-normal">{rev.content}</p>

                    {rev.photoUrl && (
                      <img
                        src={rev.photoUrl}
                        alt="후기 사진"
                        className="w-24 h-24 object-cover rounded-xl border border-gray-100"
                      />
                    )}

                    {rev.tags && rev.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-0.5">
                        {rev.tags.map((t, i) => (
                          <span
                            key={i}
                            className="text-[10px] px-2 py-0.5 bg-gray-100 text-gray-600 rounded-md"
                          >
                            #{t}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Write Review Form */}
            <form onSubmit={handleReviewSubmit} className="bg-purple-50/70 p-3.5 rounded-2xl border border-purple-100 space-y-3">
              <h4 className="text-xs font-bold text-purple-900 flex items-center gap-1">
                <span>✍️ 후기 작성하기</span>
              </h4>

              {/* User Name & Star rating */}
              <div className="flex flex-col sm:flex-row gap-2 items-start sm:items-center justify-between">
                <input
                  type="text"
                  placeholder="닉네임 (예: 구리주민)"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="bg-white text-xs px-3 py-1.5 rounded-xl border border-purple-200 focus:outline-none focus:ring-1 focus:ring-purple-400 w-full sm:w-36"
                />

                <div className="flex items-center gap-1">
                  <span className="text-xs font-semibold text-gray-600 mr-1">별점:</span>
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="text-lg focus:outline-none cursor-pointer hover:scale-110 transition"
                    >
                      <Star
                        className={`w-5 h-5 ${
                          star <= rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Preset tags */}
              <div className="flex flex-wrap gap-1">
                {PRESET_REVIEW_TAGS.map((t) => {
                  const isSel = selectedTags.includes(t);
                  return (
                    <button
                      key={t}
                      type="button"
                      onClick={() => toggleTag(t)}
                      className={`text-[10px] px-2 py-1 rounded-full border transition cursor-pointer ${
                        isSel
                          ? 'bg-purple-600 text-white border-purple-600'
                          : 'bg-white text-gray-600 border-purple-100 hover:bg-purple-100'
                      }`}
                    >
                      #{t}
                    </button>
                  );
                })}
              </div>

              {/* Content textarea */}
              <textarea
                rows={2}
                placeholder="방문해본 후기와 유용한 팁을 생생하게 들려주세요!"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full bg-white text-xs p-3 rounded-xl border border-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-400 placeholder-gray-400"
                required
              />

              {/* Photo URL option */}
              <div className="flex gap-2 items-center">
                <input
                  type="url"
                  placeholder="사진 이미지 URL (선택 사항)"
                  value={reviewPhotoUrl}
                  onChange={(e) => setReviewPhotoUrl(e.target.value)}
                  className="flex-1 bg-white text-xs px-3 py-1.5 rounded-xl border border-purple-200 focus:outline-none"
                />
                <button
                  type="submit"
                  className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-md flex items-center gap-1 transition cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>등록</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
