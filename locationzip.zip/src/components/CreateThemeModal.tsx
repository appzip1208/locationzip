import React, { useState } from 'react';
import { ThemeMap } from '../types';
import { X, Sparkles, Map, Heart } from 'lucide-react';

interface CreateThemeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateTheme: (newTheme: ThemeMap) => void;
}

const EMOJI_OPTIONS = ['🐱', '🐟', '💊', '☕', '🏃', '🚽', '🖨️', '🚲', '🐶', '📚', '🍞', '🌳', '🔌', '🍱', '🍦'];

export const CreateThemeModal: React.FC<CreateThemeModalProps> = ({
  isOpen,
  onClose,
  onCreateTheme,
}) => {
  if (!isOpen) return null;

  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [selectedEmoji, setSelectedEmoji] = useState<string>('🚲');
  const [category, setCategory] = useState<string>('생활/편의');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newTheme: ThemeMap = {
      id: `theme_custom_${Date.now()}`,
      name: name.trim(),
      description: description.trim() || '주민들이 함께 정보를 집단지성으로 만들어가는 신규 테마 지도입니다.',
      icon: selectedEmoji,
      color: '#8B5CF6',
      badgeBg: 'bg-purple-100 text-purple-800 border-purple-200',
      spotCount: 1,
      contributorCount: 1,
      isPopular: true,
      category,
    };

    onCreateTheme(newTheme);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-3xl overflow-hidden shadow-2xl border border-purple-100 flex flex-col">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-purple-600 via-pink-500 to-amber-500 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🗺️</span>
            <div>
              <h2 className="text-base font-extrabold">새 테마 지도 만들기</h2>
              <p className="text-[11px] text-purple-100 font-medium">
                우리 동네 관심 주제로 집단지성 지도 시작하기
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Emoji selector */}
          <div>
            <label className="block text-xs font-bold text-gray-800 mb-1.5">
              테마 대표 아이콘 선택
            </label>
            <div className="flex flex-wrap gap-2 p-2 bg-purple-50/60 rounded-2xl border border-purple-100">
              {EMOJI_OPTIONS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setSelectedEmoji(emoji)}
                  className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center transition cursor-pointer ${
                    selectedEmoji === emoji
                      ? 'bg-purple-600 text-white scale-110 shadow-md ring-2 ring-purple-300'
                      : 'bg-white hover:bg-purple-100 text-gray-800 border border-purple-100'
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Theme Name */}
          <div>
            <label className="block text-xs font-bold text-gray-800 mb-1">
              테마 이름
            </label>
            <input
              type="text"
              placeholder="예: 24시 따릉이/자전거 스팟, 애견동반 카페, 무인 아이스크림"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-purple-50/50 border border-purple-200 text-xs p-2.5 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400 font-bold"
              required
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-bold text-gray-800 mb-1">
              카테고리 분류
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-purple-50/50 border border-purple-200 text-xs font-bold text-gray-800 rounded-xl p-2.5 focus:outline-none focus:ring-2 focus:ring-purple-400"
            >
              <option value="동물/생태">동물/생태</option>
              <option value="먹거리">먹거리/디저트</option>
              <option value="편의/건강">편의/건강</option>
              <option value="운동/건강">운동/건강</option>
              <option value="생활/정보">생활/정보</option>
              <option value="문화/여가">문화/여가</option>
            </select>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-gray-800 mb-1">
              테마 지도 소개
            </label>
            <textarea
              rows={3}
              placeholder="주민들이 어떤 장소들을 제보해주길 원하는지 테마 목적을 소개해 주세요!"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-purple-50/50 border border-purple-200 text-xs p-2.5 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-600 via-pink-500 to-amber-500 text-white text-sm font-extrabold py-3 rounded-2xl shadow-lg hover:shadow-xl transition transform active:scale-98 cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>테마 지도 개설하기</span>
          </button>
        </form>
      </div>
    </div>
  );
};
