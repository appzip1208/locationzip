import React from 'react';
import { ThemeMap } from '../types';
import { ChevronRight, Flame } from 'lucide-react';

interface PopularThemesProps {
  themes: ThemeMap[];
  onSelectTheme: (themeId: string) => void;
  onViewAllThemes?: () => void;
}

export const PopularThemes: React.FC<PopularThemesProps> = ({
  themes,
  onSelectTheme,
  onViewAllThemes,
}) => {
  return (
    <section className="px-4 py-3">
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-1.5">
          <Flame className="w-4 h-4 text-orange-500 fill-orange-500 animate-bounce" />
          <h2 className="text-sm font-bold text-gray-900">이번주 인기 테마</h2>
        </div>
        <button
          onClick={onViewAllThemes}
          className="text-xs font-semibold text-gray-400 hover:text-purple-600 flex items-center gap-0.5 transition cursor-pointer"
        >
          <span>전체보기</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Horizontal Carousel of Popular Theme Cards */}
      <div className="flex gap-2.5 overflow-x-auto no-scrollbar pb-1">
        {themes.slice(0, 5).map((theme) => (
          <button
            key={theme.id}
            onClick={() => onSelectTheme(theme.id)}
            className="flex flex-col items-center justify-between w-22 h-26 p-2.5 bg-white rounded-2xl border border-purple-100 shadow-xs hover:shadow-md hover:border-purple-300 transition-all transform active:scale-95 shrink-0 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-2xl bg-purple-50 group-hover:bg-purple-100 flex items-center justify-center text-2xl transition">
              {theme.icon}
            </div>
            <span className="text-[11px] font-bold text-gray-800 text-center line-clamp-1 group-hover:text-purple-700">
              {theme.name}
            </span>
            <span className="text-[10px] text-gray-400 font-medium">
              {theme.spotCount}개 스팟
            </span>
          </button>
        ))}
      </div>
    </section>
  );
};
