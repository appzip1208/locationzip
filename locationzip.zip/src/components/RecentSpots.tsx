import React from 'react';
import { Spot } from '../types';
import { Star, Heart, MapPin, ChevronRight, Bookmark } from 'lucide-react';

interface RecentSpotsProps {
  spots: Spot[];
  onOpenDetail: (spot: Spot) => void;
  onToggleBookmark: (spotId: string) => void;
  onViewMore?: () => void;
}

export const RecentSpots: React.FC<RecentSpotsProps> = ({
  spots,
  onOpenDetail,
  onToggleBookmark,
  onViewMore,
}) => {
  return (
    <section className="px-4 py-3">
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-1.5">
          <span className="text-amber-400 text-sm">⭐</span>
          <h2 className="text-sm font-bold text-gray-900">새로 올라온 스팟</h2>
        </div>
        <button
          onClick={onViewMore}
          className="text-xs font-semibold text-gray-400 hover:text-purple-600 flex items-center gap-0.5 transition cursor-pointer"
        >
          <span>더보기</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="space-y-2.5">
        {spots.map((spot) => (
          <div
            key={spot.id}
            onClick={() => onOpenDetail(spot)}
            className="flex items-center gap-3 p-2.5 bg-white rounded-2xl border border-purple-100/80 shadow-xs hover:shadow-md hover:border-purple-200 transition cursor-pointer group"
          >
            {/* Image Thumbnail */}
            <div className="relative w-20 h-20 rounded-xl overflow-hidden shrink-0 bg-purple-50">
              <img
                src={spot.imageUrl}
                alt={spot.title}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded-full bg-black/60 backdrop-blur-xs text-[10px] text-white font-medium flex items-center gap-1">
                <span>{spot.themeIcon}</span>
              </div>
            </div>

            {/* Info details */}
            <div className="flex-1 min-w-0 pr-1">
              <h3 className="text-xs font-bold text-gray-900 truncate group-hover:text-purple-700 transition mb-1">
                {spot.title}
              </h3>

              <div className="flex items-center gap-1 text-[11px] text-gray-500 mb-1">
                <MapPin className="w-3 h-3 text-purple-400 shrink-0" />
                <span className="truncate">{spot.address}</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-xs font-bold text-amber-500">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>{spot.rating.toFixed(1)}</span>
                  <span className="text-gray-400 font-normal text-[11px]">({spot.reviewCount})</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleBookmark(spot.id);
                    }}
                    className="text-gray-400 hover:text-purple-600 transition p-1 cursor-pointer"
                    title="저장"
                  >
                    <Bookmark
                      className={`w-4 h-4 ${
                        spot.isBookmarked ? 'fill-purple-600 text-purple-600' : ''
                      }`}
                    />
                  </button>
                  <div className="flex items-center gap-0.5 text-xs text-pink-500 font-semibold">
                    <Heart className="w-3.5 h-3.5 fill-pink-500" />
                    <span>{spot.likes}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
