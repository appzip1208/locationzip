import React, { useState } from 'react';
import { Home, Layers, Plus, MessageCircle, User, MapPin, Sparkles } from 'lucide-react';

export type TabType = 'home' | 'themes' | 'community' | 'mypage';

interface BottomNavProps {
  currentTab: TabType;
  onChangeTab: (tab: TabType) => void;
  onOpenAddSpot: () => void;
  onOpenCreateTheme: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onChangeTab,
  onOpenAddSpot,
  onOpenCreateTheme,
}) => {
  const [showAddMenu, setShowAddMenu] = useState<boolean>(false);

  return (
    <>
      {/* Floating Action Menu Popover when Center (+) button is tapped */}
      {showAddMenu && (
        <div
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-xs flex items-end justify-center pb-20 px-4 animate-in fade-in duration-200"
          onClick={() => setShowAddMenu(false)}
        >
          <div
            className="w-full max-w-xs bg-white rounded-3xl p-3 shadow-2xl border border-purple-100 space-y-2 animate-in slide-in-from-bottom-5 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-center pb-1 border-b border-gray-100">
              <span className="text-xs font-bold text-gray-800">함께 만드는 우리 동네 지도</span>
            </div>

            <button
              onClick={() => {
                setShowAddMenu(false);
                onOpenAddSpot();
              }}
              className="w-full flex items-center gap-3 p-3 bg-purple-50 hover:bg-purple-100 text-purple-900 rounded-2xl transition text-left cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center text-lg shadow-sm group-hover:scale-105 transition">
                📍
              </div>
              <div>
                <div className="text-xs font-extrabold">새 스팟 제보하기</div>
                <div className="text-[10px] text-purple-700">이웃들에게 알려주고 싶은 정보 등록</div>
              </div>
            </button>

            <button
              onClick={() => {
                setShowAddMenu(false);
                onOpenCreateTheme();
              }}
              className="w-full flex items-center gap-3 p-3 bg-pink-50 hover:bg-pink-100 text-pink-900 rounded-2xl transition text-left cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl bg-pink-500 text-white flex items-center justify-center text-lg shadow-sm group-hover:scale-105 transition">
                🗺️
              </div>
              <div>
                <div className="text-xs font-extrabold">새 테마 지도 만들기</div>
                <div className="text-[10px] text-pink-700">새로운 관심 주제 집단지성 시작하기</div>
              </div>
            </button>
          </div>
        </div>
      )}

      {/* Main Bottom Bar matching Image 1 */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-purple-100 py-2 px-4 shadow-lg max-w-lg mx-auto">
        <div className="flex items-center justify-around relative">
          {/* Home Tab */}
          <button
            onClick={() => onChangeTab('home')}
            className={`flex flex-col items-center gap-0.5 text-[11px] font-bold transition cursor-pointer ${
              currentTab === 'home' ? 'text-purple-700' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <Home className="w-5 h-5" />
            <span>홈</span>
          </button>

          {/* Themes Tab */}
          <button
            onClick={() => onChangeTab('themes')}
            className={`flex flex-col items-center gap-0.5 text-[11px] font-bold transition cursor-pointer ${
              currentTab === 'themes' ? 'text-purple-700' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <Layers className="w-5 h-5" />
            <span>테마</span>
          </button>

          {/* Center Floating Plus Button matching Image 1 */}
          <div className="relative -top-5">
            <button
              onClick={() => setShowAddMenu(!showAddMenu)}
              className={`w-12 h-12 rounded-full bg-gradient-to-tr from-purple-600 via-purple-500 to-pink-500 text-white flex items-center justify-center shadow-lg hover:shadow-xl transition transform active:scale-95 cursor-pointer ring-4 ring-white ${
                showAddMenu ? 'rotate-45' : ''
              }`}
            >
              <Plus className="w-7 h-7 stroke-[2.5]" />
            </button>
          </div>

          {/* Community Tab */}
          <button
            onClick={() => onChangeTab('community')}
            className={`flex flex-col items-center gap-0.5 text-[11px] font-bold transition cursor-pointer ${
              currentTab === 'community' ? 'text-purple-700' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <MessageCircle className="w-5 h-5" />
            <span>커뮤니티</span>
          </button>

          {/* My Page Tab */}
          <button
            onClick={() => onChangeTab('mypage')}
            className={`flex flex-col items-center gap-0.5 text-[11px] font-bold transition cursor-pointer ${
              currentTab === 'mypage' ? 'text-purple-700' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <User className="w-5 h-5" />
            <span>마이페이지</span>
          </button>
        </div>
      </nav>
    </>
  );
};
