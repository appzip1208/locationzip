import React from 'react';
import { CommunityFeedItem } from '../types';
import { Users, MapPin, Sparkles, Heart, Clock, ArrowRight, MessageCircle } from 'lucide-react';

interface CommunityMappingInfoProps {
  feedItems: CommunityFeedItem[];
  onOpenAddSpot: () => void;
  onCreateTheme: () => void;
}

export const CommunityMappingInfo: React.FC<CommunityMappingInfoProps> = ({
  feedItems,
  onOpenAddSpot,
  onCreateTheme,
}) => {
  return (
    <div className="px-4 py-4 space-y-5 animate-in fade-in duration-300">
      {/* Title Section matching Image 2 */}
      <div className="bg-gradient-to-r from-purple-600 via-purple-700 to-pink-600 rounded-3xl p-5 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">💡</span>
            <span className="text-xs font-bold bg-white/20 px-2.5 py-0.5 rounded-full text-pink-100 backdrop-blur-xs">
              집단지성 지도의 원리
            </span>
          </div>
          <h2 className="text-xl font-extrabold tracking-tight">
            커뮤니티 매핑이란?
          </h2>
          <p className="text-xs text-purple-100/90 leading-relaxed max-w-md">
            주민들이 관심 있는 지역 주제를 제안하고, 직접 발로 뛰며 찍은 정보로 함께 지도를 그려나가는 참여형 공간 지도 프로젝트입니다.
          </p>
        </div>

        {/* Background graphic */}
        <div className="absolute -right-4 -bottom-6 text-7xl opacity-20 pointer-events-none">
          🎠
        </div>
      </div>

      {/* Visual Diagram matching Image 2 (Community + Map Making) */}
      <div className="bg-white rounded-3xl p-4 border border-purple-100 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
          {/* Card 1: Community */}
          <div className="p-3.5 bg-purple-50/80 rounded-2xl border border-purple-100 space-y-1">
            <div className="flex items-center gap-1.5 text-purple-900 font-bold text-xs">
              <span className="text-base">🎠</span>
              <span>커뮤니티</span>
            </div>
            <p className="text-[11px] text-gray-600 leading-normal">
              공간적, 지역적 단위의 사회 조직체 혹은 공통적 관심과 가치를 공유하는 집단
            </p>
          </div>

          {/* Plus separator */}
          <div className="hidden sm:flex justify-center text-purple-400 font-extrabold text-xl">
            +
          </div>

          {/* Card 2: Map Making */}
          <div className="p-3.5 bg-blue-50/80 rounded-2xl border border-blue-100 space-y-1">
            <div className="flex items-center gap-1.5 text-blue-900 font-bold text-xs">
              <span className="text-base">✏️</span>
              <span>지도 만들기</span>
            </div>
            <p className="text-[11px] text-gray-600 leading-normal">
              지리적 요소를 가진 정보를 지도에 표시하고 공유하는 일련의 집단지성 과정
            </p>
          </div>
        </div>

        {/* Bottom Banner definition matching Image 2 */}
        <div className="p-3.5 bg-gradient-to-r from-purple-900 to-indigo-900 text-white rounded-2xl text-xs font-semibold leading-relaxed shadow-sm flex items-start gap-2">
          <Sparkles className="w-4 h-4 text-pink-300 shrink-0 mt-0.5" />
          <div>
            <strong>커뮤니티 매핑은</strong> 구성원들이 함께 지역 사회 이슈와 주제(길냥이, 붕어빵, 24시 약국 등)에 대한 정보를 현장에서 수집하고 지도로 제작하여 공유하는 상생 공유 지도입니다.
          </div>
        </div>
      </div>

      {/* Action shortcuts */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          onClick={onOpenAddSpot}
          className="p-3.5 bg-gradient-to-br from-purple-500 to-purple-700 text-white rounded-2xl shadow-sm hover:shadow-md transition text-left cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xl">📍</span>
            <ArrowRight className="w-4 h-4 text-purple-200 group-hover:translate-x-1 transition" />
          </div>
          <div className="text-xs font-bold">우리동네 스팟 제보</div>
          <div className="text-[10px] text-purple-200 mt-0.5">내 단골/추천 장소 등록하기</div>
        </button>

        <button
          onClick={onCreateTheme}
          className="p-3.5 bg-gradient-to-br from-pink-500 to-amber-500 text-white rounded-2xl shadow-sm hover:shadow-md transition text-left cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xl">🗺️</span>
            <ArrowRight className="w-4 h-4 text-pink-200 group-hover:translate-x-1 transition" />
          </div>
          <div className="text-xs font-bold">새 테마 지도 개설</div>
          <div className="text-[10px] text-pink-100 mt-0.5">원하는 주제 지도 만들기</div>
        </button>
      </div>

      {/* Live Community Feed */}
      <div className="bg-white rounded-3xl p-4 border border-purple-100 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-gray-900 flex items-center gap-1.5">
            <Users className="w-4 h-4 text-purple-600" />
            <span>실시간 우리 동네 참여 소식</span>
          </h3>
          <span className="text-[10px] text-purple-600 font-semibold bg-purple-50 px-2 py-0.5 rounded-full">
            서울 · 구리 · 남양주
          </span>
        </div>

        <div className="space-y-2">
          {feedItems.map((item) => (
            <div
              key={item.id}
              className="flex items-center gap-3 p-2.5 bg-purple-50/40 hover:bg-purple-50 rounded-2xl border border-purple-100/60 transition"
            >
              <div className="w-8 h-8 rounded-full bg-white shadow-xs border border-purple-100 flex items-center justify-center text-base shrink-0">
                {item.userAvatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 text-[11px] mb-0.5">
                  <span className="font-bold text-gray-800">{item.userName}</span>
                  <span className="text-gray-400">·</span>
                  <span className="text-purple-600 font-medium">{item.region}</span>
                </div>
                <p className="text-xs font-semibold text-gray-900 truncate">{item.title}</p>
              </div>
              <div className="text-[10px] text-gray-400 shrink-0">{item.timeAgo}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
