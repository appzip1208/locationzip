import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { Spot } from '../types';
import { Plus, Minus, Navigation, Bookmark, MessageSquare, Star, MapPin } from 'lucide-react';

interface MapViewProps {
  spots: Spot[];
  selectedSpot: Spot | null;
  onSelectSpot: (spot: Spot | null) => void;
  onOpenDetail: (spot: Spot) => void;
  selectedRegion: string;
  isPickMode?: boolean;
  pickedLocation?: { lat: number; lng: number } | null;
  onPickLocation?: (location: { lat: number; lng: number; address?: string }) => void;
  onToggleBookmark: (spotId: string) => void;
}

const REGION_CENTERS: Record<string, { lat: number; lng: number; zoom: number }> = {
  '전체': { lat: 37.6100, lng: 127.1350, zoom: 12 },
  '구리': { lat: 37.6030, lng: 127.1430, zoom: 14 },
  '남양주': { lat: 37.6350, lng: 127.1500, zoom: 13 },
  '서울': { lat: 37.5950, lng: 127.0900, zoom: 13 },
};

export const MapView: React.FC<MapViewProps> = ({
  spots,
  selectedSpot,
  onSelectSpot,
  onOpenDetail,
  selectedRegion,
  isPickMode,
  pickedLocation,
  onPickLocation,
  onToggleBookmark,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});
  const pickMarkerRef = useRef<L.Marker | null>(null);

  // Initialize map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapRef.current) {
      const center = REGION_CENTERS[selectedRegion] || REGION_CENTERS['전체'];
      const map = L.map(mapContainerRef.current, {
        center: [center.lat, center.lng],
        zoom: center.zoom,
        zoomControl: false,
        attributionControl: false,
      });

      // CartoDB Positron tiles for clean pastel map design
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      mapRef.current = map;
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Update center when region changes
  useEffect(() => {
    if (mapRef.current && REGION_CENTERS[selectedRegion]) {
      const target = REGION_CENTERS[selectedRegion];
      mapRef.current.flyTo([target.lat, target.lng], target.zoom, {
        duration: 1.2,
      });
    }
  }, [selectedRegion]);

  // Handle map click for location picking
  useEffect(() => {
    if (!mapRef.current) return;

    const handleMapClick = (e: L.LeafletMouseEvent) => {
      if (isPickMode && onPickLocation) {
        const { lat, lng } = e.latlng;
        onPickLocation({ lat, lng });
      } else {
        // Deselect spot if clicking empty map area
        onSelectSpot(null);
      }
    };

    mapRef.current.on('click', handleMapClick);
    return () => {
      if (mapRef.current) {
        mapRef.current.off('click', handleMapClick);
      }
    };
  }, [isPickMode, onPickLocation, onSelectSpot]);

  // Render/Update spot markers
  useEffect(() => {
    if (!mapRef.current) return;

    const map = mapRef.current;

    // Clear previous spot markers
    Object.values(markersRef.current).forEach((m) => map.removeLayer(m));
    markersRef.current = {};

    spots.forEach((spot) => {
      const isSelected = selectedSpot?.id === spot.id;

      // Custom cute marker element using L.divIcon
      const pinHtml = `
        <div class="relative flex flex-col items-center group cursor-pointer transition-transform duration-200 ${
          isSelected ? 'scale-125 z-30' : 'hover:scale-110 z-10'
        }">
          <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-full shadow-md text-xs font-bold whitespace-nowrap border ${
            isSelected
              ? 'bg-purple-600 text-white border-purple-700 ring-4 ring-purple-200'
              : 'bg-white text-gray-800 border-purple-200 hover:border-purple-400'
          }">
            <span class="text-sm leading-none">${spot.themeIcon}</span>
            <span class="max-w-[90px] truncate">${spot.title}</span>
          </div>
          <div class="w-3 h-3 bg-purple-600 rotate-45 -mt-1.5 shadow-sm border-r border-b border-purple-700"></div>
          ${isSelected ? '<div class="absolute -bottom-1 w-4 h-1 bg-purple-400/40 rounded-full blur-xs"></div>' : ''}
        </div>
      `;

      const customIcon = L.divIcon({
        html: pinHtml,
        className: 'custom-theme-pin',
        iconSize: [120, 42],
        iconAnchor: [60, 42],
      });

      const marker = L.marker([spot.lat, spot.lng], { icon: customIcon }).addTo(map);

      marker.on('click', (e) => {
        L.DomEvent.stopPropagation(e);
        onSelectSpot(spot);
        map.panTo([spot.lat, spot.lng], { animate: true });
      });

      markersRef.current[spot.id] = marker;
    });
  }, [spots, selectedSpot, onSelectSpot]);

  // Handle picked location pin in pick mode
  useEffect(() => {
    if (!mapRef.current) return;
    const map = mapRef.current;

    if (pickMarkerRef.current) {
      map.removeLayer(pickMarkerRef.current);
      pickMarkerRef.current = null;
    }

    if (isPickMode && pickedLocation) {
      const pinHtml = `
        <div class="relative flex flex-col items-center animate-bounce">
          <div class="px-3 py-1 bg-gradient-to-r from-purple-600 to-pink-500 text-white text-xs font-bold rounded-full shadow-lg flex items-center gap-1">
            <span>📍</span> 선택한 스팟 위치
          </div>
          <div class="w-3 h-3 bg-pink-500 rotate-45 -mt-1.5 shadow-sm"></div>
        </div>
      `;
      const icon = L.divIcon({
        html: pinHtml,
        className: 'custom-theme-pin',
        iconSize: [140, 42],
        iconAnchor: [70, 42],
      });

      pickMarkerRef.current = L.marker([pickedLocation.lat, pickedLocation.lng], { icon }).addTo(map);
      map.panTo([pickedLocation.lat, pickedLocation.lng], { animate: true });
    }
  }, [isPickMode, pickedLocation]);

  const handleZoomIn = () => {
    if (mapRef.current) mapRef.current.zoomIn();
  };

  const handleZoomOut = () => {
    if (mapRef.current) mapRef.current.zoomOut();
  };

  const handleMyPosition = () => {
    if (navigator.geolocation && mapRef.current) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude, longitude } = pos.coords;
          mapRef.current?.flyTo([latitude, longitude], 15, { duration: 1.5 });
        },
        () => {
          // Fallback center to Guri/Namyangju center
          mapRef.current?.flyTo([37.6030, 127.1430], 14, { duration: 1.2 });
        }
      );
    }
  };

  return (
    <div className="relative w-full h-[360px] sm:h-[420px] rounded-3xl overflow-hidden shadow-sm border border-purple-100/80 bg-purple-50/30">
      {/* Map Element */}
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* Map Control Buttons */}
      <div className="absolute right-3 top-3 z-20 flex flex-col gap-2">
        <button
          onClick={handleZoomIn}
          className="w-9 h-9 bg-white/95 hover:bg-white text-gray-700 rounded-xl shadow-md border border-gray-100 flex items-center justify-center transition active:scale-95 cursor-pointer"
          title="확대"
        >
          <Plus className="w-5 h-5 text-purple-700" />
        </button>
        <button
          onClick={handleZoomOut}
          className="w-9 h-9 bg-white/95 hover:bg-white text-gray-700 rounded-xl shadow-md border border-gray-100 flex items-center justify-center transition active:scale-95 cursor-pointer"
          title="축소"
        >
          <Minus className="w-5 h-5 text-purple-700" />
        </button>
        <button
          onClick={handleMyPosition}
          className="w-9 h-9 bg-white/95 hover:bg-white text-gray-700 rounded-xl shadow-md border border-gray-100 flex items-center justify-center transition active:scale-95 cursor-pointer"
          title="내 위치로 이동"
        >
          <Navigation className="w-4 h-4 text-purple-600 fill-purple-100" />
        </button>
      </div>

      {/* Pick Location Instruction Banner */}
      {isPickMode && (
        <div className="absolute top-3 left-3 right-16 z-20 bg-purple-900/90 backdrop-blur-md text-white px-4 py-2.5 rounded-2xl shadow-lg text-xs font-medium flex items-center gap-2">
          <MapPin className="w-4 h-4 text-pink-300 animate-pulse shrink-0" />
          <span>지도를 터치하여 스팟 등록 위치를 지정해주세요!</span>
        </div>
      )}

      {/* Selected Spot Detail Overlay Card (Matches Image 1 design) */}
      {selectedSpot && !isPickMode && (
        <div className="absolute bottom-3 left-3 right-3 z-20 bg-white/95 backdrop-blur-md rounded-2xl p-3 shadow-xl border border-purple-100 transition-all duration-300 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex gap-3 items-center">
            <img
              src={selectedSpot.imageUrl}
              alt={selectedSpot.title}
              className="w-20 h-20 rounded-xl object-cover border border-gray-100 shrink-0 shadow-xs"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 mb-1">
                <span className="text-sm">{selectedSpot.themeIcon}</span>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${selectedSpot.themeBadgeColor}`}>
                  {selectedSpot.themeName}
                </span>
                <span className="text-[11px] text-gray-400 font-medium ml-auto">
                  {selectedSpot.region} {selectedSpot.district}
                </span>
              </div>

              <h4 className="text-sm font-bold text-gray-900 truncate mb-0.5">
                {selectedSpot.title}
              </h4>

              <div className="flex items-center gap-1 text-xs text-amber-500 font-bold mb-1">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>{selectedSpot.rating.toFixed(1)}</span>
                <span className="text-gray-400 font-normal">({selectedSpot.reviewCount})</span>
              </div>

              <p className="text-xs text-gray-600 line-clamp-1 mb-2">
                {selectedSpot.description}
              </p>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onToggleBookmark(selectedSpot.id)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold border transition cursor-pointer ${
                    selectedSpot.isBookmarked
                      ? 'bg-purple-50 text-purple-700 border-purple-200'
                      : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                  }`}
                >
                  <Bookmark
                    className={`w-3.5 h-3.5 ${
                      selectedSpot.isBookmarked ? 'fill-purple-600 text-purple-600' : ''
                    }`}
                  />
                  <span>{selectedSpot.isBookmarked ? '저장됨' : '저장'}</span>
                </button>

                <button
                  onClick={() => onOpenDetail(selectedSpot)}
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold py-1.5 px-3 rounded-xl shadow-xs transition cursor-pointer flex items-center justify-center gap-1"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>후기 보기</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
