import React, { useState } from 'react';
import { Spot, ThemeMap, Region } from '../types';
import { X, MapPin, Image as ImageIcon, Sparkles, Check, Crosshair } from 'lucide-react';

interface AddSpotModalProps {
  isOpen: boolean;
  onClose: () => void;
  themes: ThemeMap[];
  onAddSpot: (newSpot: Omit<Spot, 'id' | 'rating' | 'reviewCount' | 'likes' | 'createdAt' | 'reviews'>) => void;
  onStartPickLocation: () => void;
  pickedLocation: { lat: number; lng: number; address?: string } | null;
}

const DEFAULT_SPOT_IMAGES: Record<string, string> = {
  'theme_cat': 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=600&q=80',
  'theme_bungeo': 'https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?auto=format&fit=crop&w=600&q=80',
  'theme_pharmacy': 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80',
  'theme_cafe': 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=600&q=80',
  'theme_running': 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?auto=format&fit=crop&w=600&q=80',
  'theme_restroom': 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=600&q=80',
  'theme_print': 'https://images.unsplash.com/photo-1562654501-a0ccc0fc3fb1?auto=format&fit=crop&w=600&q=80',
};

export const AddSpotModal: React.FC<AddSpotModalProps> = ({
  isOpen,
  onClose,
  themes,
  onAddSpot,
  onStartPickLocation,
  pickedLocation,
}) => {
  if (!isOpen) return null;

  const [selectedThemeId, setSelectedThemeId] = useState<string>(themes[0]?.id || 'theme_cat');
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [region, setRegion] = useState<'서울' | '구리' | '남양주'>('구리');
  const [district, setDistrict] = useState<string>('인창동');
  const [address, setAddress] = useState<string>('');
  const [imageUrl, setImageUrl] = useState<string>('');
  const [tags, setTags] = useState<string>('친절함, 추천');
  const [author, setAuthor] = useState<string>('');

  const selectedTheme = themes.find((t) => t.id === selectedThemeId) || themes[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    // Use picked location or default region coordinates
    const lat = pickedLocation?.lat || (region === '구리' ? 37.6030 : region === '남양주' ? 37.6350 : 37.5950);
    const lng = pickedLocation?.lng || (region === '구리' ? 127.1430 : region === '남양주' ? 127.1500 : 127.0900);

    const finalImage = imageUrl.trim() || DEFAULT_SPOT_IMAGES[selectedThemeId] || DEFAULT_SPOT_IMAGES['theme_cat'];

    const tagList = tags
      .split(',')
      .map((t) => t.trim().replace(/^#/, ''))
      .filter(Boolean);

    onAddSpot({
      themeId: selectedTheme.id,
      themeName: selectedTheme.name,
      themeIcon: selectedTheme.icon,
      themeBadgeColor: selectedTheme.badgeBg,
      title,
      description,
      region,
      district,
      address: address.trim() || `경기 ${region}시 ${district} 주민추천 스팟`,
      lat,
      lng,
      imageUrl: finalImage,
      tags: tagList,
      author: author.trim() || '동네이웃',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white rounded-3xl max-h-[90vh] overflow-y-auto no-scrollbar shadow-2xl border border-purple-100 flex flex-col">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-purple-600 via-purple-500 to-pink-500 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📍</span>
            <div>
              <h2 className="text-base font-extrabold leading-tight">우리동네 새 스팟 등록</h2>
              <p className="text-[11px] text-purple-100 font-medium">
                이웃들에게 알려주고 싶은 우리 동네 정보 등록하기
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Theme Category Select */}
          <div>
            <label className="block text-xs font-bold text-gray-800 mb-1.5">
              1. 테마 카테고리 선택
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {themes.map((theme) => {
                const isSelected = selectedThemeId === theme.id;
                return (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => setSelectedThemeId(theme.id)}
                    className={`flex items-center gap-2 p-2 rounded-2xl border text-xs font-bold transition cursor-pointer ${
                      isSelected
                        ? 'bg-purple-600 text-white border-purple-700 shadow-md ring-2 ring-purple-200'
                        : 'bg-purple-50/50 text-gray-700 border-purple-100 hover:bg-purple-100/60'
                    }`}
                  >
                    <span className="text-lg">{theme.icon}</span>
                    <span className="truncate">{theme.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Region & District */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-gray-800 mb-1">
                2. 지역
              </label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value as '서울' | '구리' | '남양주')}
                className="w-full bg-purple-50/50 border border-purple-200 text-xs font-bold text-gray-800 rounded-xl p-2.5 focus:outline-none focus:ring-2 focus:ring-purple-400"
              >
                <option value="구리">구리시</option>
                <option value="남양주">남양주시</option>
                <option value="서울">서울 (동부)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-800 mb-1">
                3. 동/구 명칭
              </label>
              <input
                type="text"
                placeholder="예: 인창동, 다산동"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full bg-purple-50/50 border border-purple-200 text-xs p-2.5 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400"
                required
              />
            </div>
          </div>

          {/* Interactive Location Pick */}
          <div className="bg-purple-50 p-3 rounded-2xl border border-purple-100 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-900 flex items-center gap-1">
                <MapPin className="w-4 h-4 text-purple-600" />
                <span>4. 지도에서 위치 지정하기</span>
              </span>
              <button
                type="button"
                onClick={() => {
                  onStartPickLocation();
                  onClose();
                }}
                className="bg-purple-600 hover:bg-purple-700 text-white text-[11px] font-bold px-3 py-1.5 rounded-xl shadow-xs transition flex items-center gap-1 cursor-pointer"
              >
                <Crosshair className="w-3.5 h-3.5" />
                <span>지도 위치 선택</span>
              </button>
            </div>

            {pickedLocation ? (
              <div className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 p-2 rounded-xl border border-emerald-200 flex items-center gap-1">
                <Check className="w-4 h-4" />
                <span>선택된 좌표: {pickedLocation.lat.toFixed(4)}, {pickedLocation.lng.toFixed(4)}</span>
              </div>
            ) : (
              <p className="text-[11px] text-gray-500">
                버튼을 눌러 지도 위에서 위치를 직접 찍을 수 있어요!
              </p>
            )}

            <input
              type="text"
              placeholder="상세 주소 (예: 경기 구리시 인창동 670-1 공원 근처)"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full bg-white text-xs p-2.5 rounded-xl border border-purple-200 focus:outline-none focus:ring-1 focus:ring-purple-400"
            />
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-gray-800 mb-1">
              5. 스팟 명칭
            </label>
            <input
              type="text"
              placeholder="예: 장자호수공원 바삭 붕어빵 삼거리"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-purple-50/50 border border-purple-200 text-xs p-2.5 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-gray-800 mb-1">
              6. 상세 후기 및 팁
            </label>
            <textarea
              rows={3}
              placeholder="위치 찾아가는 법, 추천 이용 시간, 특징 등을 이웃들에게 공유해 주세요!"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-purple-50/50 border border-purple-200 text-xs p-2.5 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400"
              required
            />
          </div>

          {/* Image URL & Tags */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-gray-800 mb-1">
                대표 사진 URL (선택)
              </label>
              <input
                type="url"
                placeholder="https://..."
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                className="w-full bg-purple-50/50 border border-purple-200 text-xs p-2.5 rounded-xl focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-800 mb-1">
                태그 (쉼표 구분)
              </label>
              <input
                type="text"
                placeholder="예: 24시, 길냥이친화적"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                className="w-full bg-purple-50/50 border border-purple-200 text-xs p-2.5 rounded-xl focus:outline-none"
              />
            </div>
          </div>

          {/* Author */}
          <div>
            <label className="block text-xs font-bold text-gray-800 mb-1">
              작성자 닉네임
            </label>
            <input
              type="text"
              placeholder="예: 인창동집사"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              className="w-full bg-purple-50/50 border border-purple-200 text-xs p-2.5 rounded-xl focus:outline-none"
            />
          </div>

          {/* Submit button */}
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-600 via-purple-700 to-pink-600 text-white text-sm font-extrabold py-3 rounded-2xl shadow-lg hover:shadow-xl transition transform active:scale-98 cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>이웃과 공유하기 (스팟 등록)</span>
          </button>
        </form>
      </div>
    </div>
  );
};
