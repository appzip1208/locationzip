import React, { useState } from 'react';
import { Spot } from '../types';
import { Award, Bookmark, MapPin, Heart, Star, Settings, ChevronRight, User, ShieldCheck } from 'lucide-react';

interface MyPageProps {
  bookmarkedSpots: Spot[];
  mySpots: Spot[];
  onOpenSpotDetail: (spot: Spot) => void;
  onToggleBookmark: (spotId: string) => void;
}

export const MyPage: React.FC<MyPageProps> = ({
  bookmarkedSpots,
  mySpots,
  onOpenSpotDetail,
  onToggleBookmark,
}) => {
  const [activeTab, setActiveTab] = useState<'saved' | 'created' | 'badges'>('saved');

  return (
    <div className="px-4 py-4 space-y-4 animate-in fade-in duration-300">
      {/* Profile Card */}
      <div className="bg-gradient-to-br from-purple-600 via-purple-700 to-pink-600 rounded-3xl p-5 text-white shadow-lg space-y-4 relative overflow-hidden">
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center text-3xl shadow-inner">
              🐱
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-lg font-extrabold">구리냥이덕후</h2>
                <span className="text-[10px] bg-amber-400 text-amber-950 font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5 shadow-xs">
                  <ShieldCheck className="w-3 h-3" /> Lv.4 골드 매퍼
                </span>
              </div>
              <p className="text-xs text-purple-100 font-medium mt-0.5">
                주활동 지역: 경기 구리시 인창동 · 토평동
              </p>
            </div>
          </div>

          <button className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition cursor-pointer">
            <Settings className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/15 text-center">
          <div className="p-2 bg-white/10 rounded-2xl backdrop-blur-xs">
            <div className="text-base font-extrabold">{mySpots.length}</div>
            <div className="text-[11px] text-purple-200">등록 스팟</div>
          </div>
          <div className="p-2 bg-white/10 rounded-2xl backdrop-blur-xs">
            <div className="text-base font-extrabold">{bookmarkedSpots.length}</div>
            <div className="text-[11px] text-purple-200">저장 장소</div>
          </div>
          <div className="p-2 bg-white/10 rounded-2xl backdrop-blur-xs">
            <div className="text-base font-extrabold">128</div>
            <div className="text-[11px] text-purple-200">받은 좋아요</div>
          </div>
        </div>

        {/* Decorative circle */}
        <div className="absolute -right-10 -bottom-10 w-36 h-36 bg-pink-400/20 rounded-full blur-2xl pointer-events-none"></div>
      </div>

      {/* Tabs */}
      <div className="flex bg-gray-100 p-1 rounded-2xl">
        <button
          onClick={() => setActiveTab('saved')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1 ${
            activeTab === 'saved'
              ? 'bg-white text-purple-700 shadow-xs'
              : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>저장한 장소 ({bookmarkedSpots.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('created')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1 ${
            activeTab === 'created'
              ? 'bg-white text-purple-700 shadow-xs'
              : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          <MapPin className="w-3.5 h-3.5" />
          <span>내가 등록한 스팟 ({mySpots.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('badges')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1 ${
            activeTab === 'badges'
              ? 'bg-white text-purple-700 shadow-xs'
              : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>활동 뱃지</span>
        </button>
      </div>

      {/* Tab Contents */}
      {activeTab === 'saved' && (
        <div className="space-y-2.5">
          {bookmarkedSpots.length === 0 ? (
            <div className="text-center py-10 bg-white rounded-3xl border border-purple-100 text-gray-400 text-xs">
              아직 저장한 스팟이 없습니다. 지도에서 마음에 드는 곳을 저장해 보세요! 🔖
            </div>
          ) : (
            bookmarkedSpots.map((spot) => (
              <div
                key={spot.id}
                onClick={() => onOpenSpotDetail(spot)}
                className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-purple-100 shadow-2xs hover:shadow-md transition cursor-pointer"
              >
                <img
                  src={spot.imageUrl}
                  alt={spot.title}
                  className="w-16 h-16 rounded-xl object-cover border border-gray-100 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1 mb-0.5">
                    <span className="text-xs">{spot.themeIcon}</span>
                    <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">
                      {spot.themeName}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-gray-900 truncate">{spot.title}</h4>
                  <p className="text-[11px] text-gray-500 truncate">{spot.address}</p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleBookmark(spot.id);
                  }}
                  className="text-purple-600 p-2 hover:bg-purple-50 rounded-xl transition cursor-pointer"
                >
                  <Bookmark className="w-4 h-4 fill-purple-600" />
                </button>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'created' && (
        <div className="space-y-2.5">
          {mySpots.map((spot) => (
            <div
              key={spot.id}
              onClick={() => onOpenSpotDetail(spot)}
              className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-purple-100 shadow-2xs hover:shadow-md transition cursor-pointer"
            >
              <img
                src={spot.imageUrl}
                alt={spot.title}
                className="w-16 h-16 rounded-xl object-cover border border-gray-100 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1 mb-0.5">
                  <span className="text-xs">{spot.themeIcon}</span>
                  <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">
                    {spot.themeName}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-gray-900 truncate">{spot.title}</h4>
                <div className="flex items-center gap-2 text-[11px] text-amber-500 font-bold mt-1">
                  <span>★ {spot.rating.toFixed(1)}</span>
                  <span className="text-gray-400">·</span>
                  <span className="text-pink-500 flex items-center gap-0.5">
                    <Heart className="w-3 h-3 fill-pink-500" /> {spot.likes}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'badges' && (
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3.5 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl border border-amber-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-white flex items-center justify-center text-xl shadow-xs">
              🐱
            </div>
            <div>
              <div className="text-xs font-bold text-amber-900">냥덕후 마스터</div>
              <div className="text-[10px] text-amber-700">고양이 스팟 5개 이상 제보</div>
            </div>
          </div>

          <div className="p-3.5 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-2xl border border-purple-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500 text-white flex items-center justify-center text-xl shadow-xs">
              🐟
            </div>
            <div>
              <div className="text-xs font-bold text-purple-900">붕어빵 탐험가</div>
              <div className="text-[10px] text-purple-700">붕어빵 스팟 3개 이상 작성</div>
            </div>
          </div>

          <div className="p-3.5 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl border border-emerald-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-white flex items-center justify-center text-xl shadow-xs">
              💊
            </div>
            <div>
              <div className="text-xs font-bold text-emerald-900">동네 보안관</div>
              <div className="text-[10px] text-emerald-700">24시 약국 정보 제보자</div>
            </div>
          </div>

          <div className="p-3.5 bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl border border-pink-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-pink-500 text-white flex items-center justify-center text-xl shadow-xs">
              ☕
            </div>
            <div>
              <div className="text-xs font-bold text-pink-900">카페 감성꾼</div>
              <div className="text-[10px] text-pink-700">숨은 카페 후기 작성완료</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
